<?php

\Core\Router::attachView('installation');