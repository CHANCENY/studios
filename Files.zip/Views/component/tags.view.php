<section class="w-100 text-white">
    <div class="line mt-lg-5 h-auto border-start border-primary ps-5 ms-1 border-4 d-inline-flex w-100">
        <div><?php echo $title; ?></div>
    </div>
    <hr class="">
</section>