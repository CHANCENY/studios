<?php @session_start(); ?>
<section class="container mt-lg-5">
    <div class="w-50 m-auto">
        <input type="search" class="form-control" name="search" id="search" placeholder="movie">
    </div>
</section>
<section class="w-100 mt-lg-5 ms-lg-3">
    <div class="row m-auto justify-content-center" id="result-box">

   </div>
</section>

<section style="margin-top: 100%;"></section>

<script src="assets/my-styles/js/tmdbsearch.js"></script>
