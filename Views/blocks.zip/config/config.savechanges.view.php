<?php

use ApiHandler\ApiHandlerClass;
use GlobalsFunctions\Globals;
use Datainterface\Updating;

$id = Globals::get('id');
$data['value'] = Globals::get('value');
echo ApiHandlerClass::stringfiyData(['status'=>Updating::update('api_configuration_keys_value'
    ,$data, ['rowid'=>$id])]);
exit;