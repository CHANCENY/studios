<?php

use Datainterface\Database;
use Datainterface\mysql\InsertionLayer;
use Datainterface\mysql\SelectionLayer;
use Datainterface\MysqlDynamicTables;
use GlobalsFunctions\Globals;

$t = 'api_configuration_keys_value';
$col = ['name', 'value'];
$attr = ['name'=>['varchar(250)', 'not null'], 'value'=>['text', 'not null']];
(new MysqlDynamicTables())->resolver(Database::database(),$col, $attr, $t);

if(Globals::method() === 'POST'){
    $data = ['name'=>Globals::post('name'), 'value'=>Globals::post('value')];

    //make unique
    $found = (new SelectionLayer())->setTableName($t)->setKeyValue(['name'=>Globals::post('name')])->selectBy()->rows();
    if(empty($found)){
        (new InsertionLayer())->setTableName($t)->setData($data)->insert();
    }else{
        echo \Alerts\Alerts::alert('warning',"Name of config is not unique");
    }
}
$items = (new SelectionLayer())->setTableName($t)->selectAll()->rows();
$i = 0;
?>
<section class="container mt-lg-5">
    <div class="w-75 m-auto">
        <button type="button" class="btn btn-primary mb-lg-2" id="add-new">New</button>
        <table class="table mt-4">
            <thead class="text-white-50">
            <tr>
                <th>Name</th>
                <th>Value</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody class="text-white-50">
            <?php if(!empty($items)): ?>
                <?php foreach ($items as $item=>$value): ?>
                    <tr>
                        <td><?php echo $value['name'] ?? null; ?></td>
                        <td>
                            <input type="text" value="<?php echo $value['value'] ?? null; ?>" class="border-dark border-1 rounded w-100" id="value-<?php echo $i; ?>">
                        </td>
                        <td>
                            <button data="<?php echo $value['rowid'] ?? null; ?>" class="btn btn-outline-light" id="action-<?php echo $i; ?>">Save Changes</button>
                        </td>
                    </tr>
                    <?php $i++; endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
        <div id="temp" data="<?php echo $i; ?>"></div>
        <div class="mt-lg-5" id="new-form">

        </div>
    </div>
</section>

<script type="application/javascript">
    const total = 2;
    function makeForm(){
        const form = document.createElement('form');
        form.action = '#';
        form.method = 'POST';
        form.className = 'form w-50';

        const nameField = document.createElement('input');
        nameField.type = 'text';
        nameField.name = 'name';
        nameField.id = 'name';
        nameField.placeholder = "Name";
        nameField.className = "form-control"

        const valueField = document.createElement('input');
        valueField.type = 'text';
        valueField.name = 'value';
        valueField.id = 'value';
        valueField.placeholder = "Value";
        valueField.className = "form-control";

        const label = document.createElement('label');
        label.htmlFor = "name";
        label.textContent = "Name";

        const label1 = document.createElement('label');
        label1.htmlFor = "value";
        label1.textContent = "Value";

        const div = document.createElement('div');
        div.className= "form-group";

        const div1 = document.createElement('div');
        div1.className= "form-group";

        const button = document.createElement('button');
        button.className = "btn btn-primary mt-lg-4";
        button.textContent = "Save";
        button.type = "submit";
        button.name = "add-new"

        div.appendChild(label);
        div.appendChild(nameField);

        div1.appendChild(label1);
        div1.appendChild(valueField);

        form.appendChild(div);
        form.appendChild(div1);
        form.appendChild(button);
        return form;

    }

    const newAdd = document.getElementById('add-new');
    if(newAdd !== null){
        newAdd.addEventListener('click', ()=>{
            const formMade = makeForm();
            const area = document.getElementById('new-form');
            if(area !== null){
                area.appendChild(formMade);
                newAdd.setAttribute('disabled', 'true');
            }
        })
    }

    const tempId = parseInt(document.getElementById('temp').getAttribute('data'))
    for(let i = 0; i <= tempId; i++){
        const btn = document.getElementById('action-'+i);
        if(btn !== null){
           btn.addEventListener('click', (e)=>{
               const inputValue = document.getElementById('value-'+i).value;
               const itemId = btn.getAttribute('data');
               const params = new URLSearchParams({id: itemId, value: inputValue});
               const xhr = new XMLHttpRequest();
               xhr.open('GET', 'config-config-api?'+params, true);
               xhr.setRequestHeader('Content-Type', 'application/json');
               xhr.onload = function (){
                   console.log(this.responseText);
                   const data = JSON.parse(this.responseText);
                   if(data.status === true){
                       window.location.reload();
                   }
               }
               xhr.send();
           })
        }
    }
</script>