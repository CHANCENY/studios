<?php

use GlobalsFunctions\Globals;
use RoutesManager\RoutesManager;

$viewsInSystem = (new RoutesManager())->loadRoutes()->getRoutes();
?>

<?php if(!empty(Globals::user())): ?>

<?php if(!empty($viewsInSystem)): ?>

<div class="d-inline-flex w-100 m-auto">
    <div class="row"><?php foreach ($viewsInSystem as $key=>$menu): ?><?php if($menu['view_role_access'] === 'moderator'): ?>
        <a href="<?php echo $menu['view_url'] ?? null; ?>" class="btn btn-outline-light w-auto mx-2 ms-2 mt-2 mb-2"><?php echo $menu['view_name'] ?? null; ?></a><?php endif; ?><?php endforeach; ?>
    </div>
</div>
    <script type="application/javascript">
        function clicking(e){
            window.location.replace(e.getAttribute('data'));
        }
    </script>
<?php endif; ?>

<?php endif; ?>
