<?php
 \Core\Router::attachView('tags',['title'=>'Tv Shows']);
 \Core\Router::attachView('tv-shows',['fromIndex'=>true]);
 \Core\Router::attachView('tags',['title'=>'Movies']);
 \Core\Router::attachView('movies',['fromIndex'=>true]);
?>